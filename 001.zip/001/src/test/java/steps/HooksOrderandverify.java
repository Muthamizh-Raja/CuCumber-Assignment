package steps;
import cucumber.api.Scenario;
import cucumber.api.java.*;

public class HooksOrderandverify {
@Before
	public void preScenario(Scenario sc){
	System.out.println("Scenario Name:" +sc.getName());
	System.out.println("Line Name:" +sc.getId());
		
	}
@After
public void postScenario(Scenario sc){
	System.out.println("Status" +sc.getStatus());
	
}

}
