package steps;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import config.ConfigFileReader;
public class createandverifyorder {
	public ChromeDriver driver;
	
	ConfigFileReader configFileReader;
	 @Given("Launch the Browser")
	public void launch_the_Browser() {
		 WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver();
		 configFileReader =new ConfigFileReader();
		//System.setProperty("webdriver.chrome.driver",configFileReader.getDriverPath());
		 //driver = new ChromeDriver();
	 }	
@Given("Load the URL")
	public void load_the_URL() {
	
	   driver.get(configFileReader.getApplicationUrl());
	}
@Given("Maximise the Browser")
	public void maximise_the_Browser() {
		driver.manage().window().maximize();
}
@Given("Set the Timeouts")
	public void set_the_Timeouts() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	}
@Given("Click on the signin Button")
public void Click_on_the_signin_Button() {
	driver.findElementByClassName("login").click();
}

	@Given("Enter EmailAddress as (.*)")
	public void Enter_EmailAddress(String EmailAdress ) {
		driver.findElementById("email").sendKeys(configFileReader.EmailAddress());
	   
	}

	@Given("Enter Password as (.*)")
	public void Enter_Password (String Password) {
		driver.findElementById("passwd").sendKeys(configFileReader.Password());
	}

	@When("Click on the Signin Button")
	public void click_on_the_Signin_Button() {
		driver.findElementById("SubmitLogin").click();
	}

	@Given("Click TSHIRTS Tab")
	public void click_TSHIRTS_Tab() {
		driver.findElementByLinkText("T-shirts").click();
	}

	@Given("Click on the Add to cart Button")
	public void Click_on_the_Add_to_cart_Button() {
		driver.findElementByLinkText("Add to cart").click();
	}

	@Given("Click on the Proceed to checkout Button")
	public void Click_on_the_Proceed_to_checkout_Button() {
		driver.findElementByLinkText("Proceed to checkout").click();
	}
	
	@Given("Click on the Proceed to checkout Button1")
	public void Click_on_the_Proceed_to_checkout_Button1(){
		driver.findElementById("Proceed to checkout").click();;
	    	}

	@Given("Click_on_the_Proceed_to_checkout_Button2()")
	public void Click_on_the_Proceed_to_checkout_Button2() {
		 driver.findElementByName("processAddress").click();
	}

	@Given("checkin the checkox to agree license")
	public void checkin_the_checkox_to_agree_license() {
		driver.findElementById("cgv").isSelected();
	}

	@Given("Click on the Proceed to checkout Button3")
	public void Click_on_the_Proceed_to_checkout_Button3() {
		driver.findElementByName("processCarrier").click();
	}

	@Given("Click on the Pay by check Button")
	public void Click_on_the_Pay_by_check_Button() {
		driver.findElementByLinkText("Pay by check").click();
	}
		@Given("Click on the I confirm my order Button")
		public void Click_on_the_I_confirm_my_order_Button() {
			driver.findElementByClassName("button btn btn-default button-medium").click();
	
		}
		@Given("Click on the back to orders Button")
		public void Click_on_the_back_to_orders_Button() {
		driver.findElementByLinkText("Back to orders").click();
		}
		/*@Then("Verify order completion is success")
		public void Click_on_the_back_to_orders_Button() {
			driver.findElementByLinkText("Back to orders").click();
			}*/
		
		
}
	



